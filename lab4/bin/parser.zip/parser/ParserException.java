package parser;

public class ParserException extends RuntimeException {
    public ParserException(String message) {
        super(message);
    }
}
